// Creating a thread
class MyThread extends Thread
{
	MyThread()
	{
		start();
	}
	public void run()
	{
		for(int i=1;i<3;i++)
			System.out.println(i);
		System.out.println("jfdjfljdlfjalf");
		System.out.println("jfdjfljdlfjalf");
	}
}
class ThrDemo
{
	public static void main(String[] args) 
	{

		//Creating an object of the class
		//MyThread obj = new MyThread();
		//Create a thread and attach the obj
		//Thread t = new Thread(obj);
		// Run the thread
		//t.start();
		new MyThread();//.start();
		new MyThread();//.start();
		new MyThread();//.start();

	}
}