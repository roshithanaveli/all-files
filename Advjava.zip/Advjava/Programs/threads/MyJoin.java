//Demo on join()
class MyJoin extends Thread
{
	public void run()
	{
		for(int i=1;i<9;i++)
		{
			System.out.println(Thread.currentThread().getName()+" is here ......");
		}
		System.out.println(Thread.currentThread().getName()+" is ending ......");
	}
	public static void main(String[] args) 
	{
		MyJoin obj = new MyJoin();
		
		Thread t1 = new Thread(obj,"First");
		Thread t2 = new Thread(obj,"Second");
		Thread t3 = new Thread(obj,"Third");

		t1.start();
		t2.start();
		t3.start();

		System.out.println(t1.getState());
		System.out.println(t2.getState());
		System.out.println(t3.getState());
		
		Thread t = Thread.currentThread();
		
		try{
			t.join();
			t1.join();
			t2.join();
			t3.join();
		}catch (InterruptedException e){}
		
		System.out.println(t1.getState());
		System.out.println(t2.getState());
		System.out.println(t3.getState());

		System.out.println(Thread.currentThread().getName()+"ending here ......");
	}
}
