// Booking a Ticket
class BookTicket extends Thread
{
	Object train, comp;
	BookTicket(Object train, Object comp)
	{
		this.train = train;
		this.comp = comp;
	}
	public void run()
	{
		synchronized(train)
		{
			System.out.println("Book Ticket has locked the train");
			try{
				Thread.sleep(1000);
			}
			catch(InterruptedException ie){}
			System.out.println("Book Ticket wants to lock on compartment");
			synchronized(comp)
			{
				System.out.println("Book Ticket has locked the compartment");
			}
		}
	}
}