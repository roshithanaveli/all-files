// Thread Communication
class Communicate 
{
	public static void main(String[] args) throws Exception
	{
		Producer obj1 = new Producer();
		Consumer obj2 = new Consumer(obj1);
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		t1.start();
		t2.start();
	}
}
class Producer extends Thread
{
	StringBuffer sb;
	boolean dataprodover = false;
	Producer()
	{
		sb = new StringBuffer();
	}
	public void run()
	{
		synchronized(sb){
			for(int i=0;i<10;i++){
				try{
					sb.append(i+":");
					Thread.sleep(1000);
					System.out.println("Appending");
				}
				catch(Exception e){}
			}
			dataprodover = true;
			//sb.notify();
		}
	}
}
class Consumer extends Thread
{
	Producer prod;
	Consumer(Producer prod)
	{
		this.prod = prod;
	}
	public void run()
	{
		synchronized(prod.sb){
			/*try{
				while(!prod.dataprodover)
					//Thread.sleep(100);
			}
			catch(Exception e){}*/
			System.out.println(prod.sb);
		}
	}
}