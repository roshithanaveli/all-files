// Cancellation of Ticket
class CancelTicket extends Thread
{
	Object train, comp;
	CancelTicket(Object train, Object comp)
	{
		this.train = train;
		this.comp = comp;
	}
	public void run()
	{
		synchronized(comp)
		{
			System.out.println("Cancel Ticket has locked the Compartment");
			try{
				Thread.sleep(1000);
			}
			catch(InterruptedException ie){}
			System.out.println("Cancel Ticket wants to lock on train ");
			synchronized(train)
			{
				System.out.println("Cancel Ticket has locked the train");
			}
		}
	}
}