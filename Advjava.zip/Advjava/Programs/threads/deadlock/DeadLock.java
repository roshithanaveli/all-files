// Now perform cancellation and booking
class DeadLock 
{
	public static void main(String[] args) throws Exception
	{
		// Take Train and Compartment as objects
		Object train = new Object();
		Object comp = new Object();
		
		// Create Objects to CancelTicket, BookTicket
		CancelTicket obj1 = new CancelTicket(train,comp);
		BookTicket obj2 = new BookTicket(train,comp);
		
		// Create 2 threads and attach to obj1 and obj2
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		
		// now run the threads
		t1.start();
		t2.start();
	}
}