// DEMO ON THREAD.JOIN METHOD
class CustomThread extends Thread
{
	public void run()
	{
		//try
		//{
			Thread t = Thread.currentThread();
			for(int i=1; i<6; i++)
			{
				System.out.println((Thread.currentThread()).getName()
				+ " thread here..."+i);
			}
			System.out.println((Thread.currentThread()).getName() +
			" ending.");
			//t.join();	
		//}
		/*catch (InterruptedException e)
		{
		}*/
		
	}
}
class Join
{
	public static void main(String args[])
	{
		
		CustomThread thread1 = new CustomThread();
		CustomThread thread2 = new CustomThread();
		CustomThread thread3 = new CustomThread();
		
		Thread t = Thread.currentThread();

		Thread t1 = new Thread(thread1,"first");
		Thread t2 = new Thread(thread2,"second");
		Thread t3 = new Thread(thread3,"third");
		
		t1.start();
		t2.start();
		t3.start();
		
		System.out.println(t1.getState());
		System.out.println(t2.getState());
		System.out.println(t3.getState());
		
		try{
			t1.join();
			t2.join();
			//t3.join();
			//t.join();
		}catch(Exception e){}

		System.out.println(t1.getState());
		System.out.println(t2.getState());
		System.out.println(t3.getState());
	
	}
}