//demo on jdbc type1 driver
import java.sql.*;
class Con1
{
	public static void main(String[] args) 
	{
		Connection con = null;
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con = DriverManager.getConnection("jdbc:odbc:oradsn","surya","surya");
			System.out.println("Connected ........");
			Thread.sleep(500);
			con.close();
			System.out.println("Disconnected ........");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}