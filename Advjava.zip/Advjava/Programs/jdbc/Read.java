import java.sql.*;
class Read
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","surya","surya");
			Statement stmt = con.createStatement();

			String str = "select * from student";

			ResultSet rs = stmt.executeQuery(str);

			while(rs.next())
			{
				System.out.println("Current Row ---> "+rs.getRow());

				System.out.println(rs.getString("sid"));
				System.out.println(rs.getString("sname"));
				System.out.println(rs.getString("age"));
				System.out.println(rs.getString("address"));
			}
		}
		catch(Exception e){}
	}
}