import java.sql.*;
class Stmt
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","surya","surya");

			long t1,t2,diff;
			Statement stmt = con.createStatement();
			t1 = System.currentTimeMillis();
			for(int i=1;i<=100;i++)
			{

				String vsql = "insert into tt values("+i+","+i+","+i+")";
				stmt.executeUpdate(vsql);
			}

			t2 = System.currentTimeMillis();
			diff = t2 - t1;
			System.out.println("Diff --> "+diff);
			con.close();
		}
		catch(Exception e){
			System.out.println("Error --> "+e);
		}
	}
}