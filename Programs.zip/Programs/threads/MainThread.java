// EVERY PROGRAM IS EXECUTED BY A THREAD
class MainThread
{
	public static void main(String[] args) 
	{
		System.out.println("This is First Statement");
		Thread t = Thread.currentThread();
		System.out.println(t);
		System.out.println(t.MAX_PRIORITY);
		System.out.println(t.MIN_PRIORITY);
		System.out.println(t.NORM_PRIORITY);
		System.out.println("Its name : "+t.getName());
		display();
	}
	static void display()
	{
		Thread t = new Thread();
		System.out.println(t);
		Thread t1 = new Thread();
		System.out.println(t1);
	}
}