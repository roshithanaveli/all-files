//Thread Priority
class MyCls extends Thread
{
	int count = 0;
	public void run()
	{
		for(int i=0;i<1000;i++)
			++count;
		System.out.println("Completed = "+Thread.currentThread().getName());
		System.out.println("Its priority = "+Thread.currentThread().getPriority());
	}
	public static void main(String[] args) 
	{
		MyCls obj = new MyCls();

		Thread t1 = new Thread(obj,"one");
		Thread t2 = new Thread(obj,"two");

		t1.setPriority(1);
		t2.setPriority(6);

		t1.start();
		t2.start();
	}
}