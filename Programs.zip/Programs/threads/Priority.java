// THREAD PRIORITY
class MyClass extends Thread
{
	public void run()
	{
		String name = Thread.currentThread().getName();
		for(int i=0;i<6;i++)
		{
			System.out.println(name+i);
			/*try{
				Thread.sleep(100);
			}catch(Exception e){}*/
		}
		System.out.println("Completed : "+name);
		System.out.println("Its Priority : "+Thread.currentThread().getPriority());
	}
}
class Priority
{
	public static void main(String[] args) 
	{
		MyClass	obj = new MyClass();
		
		Thread t1 = new Thread(obj,"one");
		Thread t2 = new Thread(obj,"two");
		Thread t3 = new Thread(obj,"thr");
		
		//set priority to these threads
		t1.setPriority(Thread.MIN_PRIORITY);
		t2.setPriority(Thread.NORM_PRIORITY);
		t3.setPriority(Thread.MAX_PRIORITY);
		
		t1.start();	
		t3.start();
		t2.start();
	
	}
}