//Two Threads running on two objects
class Theatre extends Thread
{
	String name;
	Theatre(String str)
	{
		name = str;
	}
	public void run()
	{
		for(int i=1;i<11;i++)
		{
			System.out.println(name+i);
			try{
				Thread.sleep(2000);
			}catch(InterruptedException ie){}
		}
	}
	public static void main(String[] args) 
	{
		Theatre obj1 = new Theatre("Show Ticket");
		Theatre obj2 = new Theatre("Cut Ticket");

		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);

		t1.start();
		t2.start();
	}
}