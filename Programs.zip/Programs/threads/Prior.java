//demo on thread priority
class Prior extends Thread
{
	int count = 0;
	public void run()
	{
		for(int i=1;i<1000;i++)
			++count;
		System.out.println("Completed = "+Thread.currentThread().getName());
		System.out.println("Its Priority = "+Thread.currentThread().getPriority());
	}
	public static void main(String[] args) 
	{
		Prior obj = new Prior();

		Thread t1 = new Thread(obj,"one");
		Thread t2 = new Thread(obj,"two");
		Thread t3 = new Thread(obj,"thr");

		t1.setPriority(6);
		t2.setPriority(1);
		t3.setPriority(Thread.MAX_PRIORITY);

		t1.start();
		t2.start();
		t3.start();
	}
}
