//Two Thread running on the same object
class Reservation extends Thread
{
	int available = 1;
	int wanted;

	Reservation(int i)
	{
		wanted = i;
	}

	public void run()
	{
		synchronized(this){
		System.out.println("No of Berths available : "+available);
		String name = Thread.currentThread().getName();
			
		if(wanted<=available)
		{
			System.out.println(wanted+" berths alloted for "+name);
			try{
				Thread.sleep(2000);
			}catch(InterruptedException ie){}
			available -= wanted;
		}
		else{
			System.out.println("No berths are alloted for "+name);
		}
		System.out.println("No of Berths available : "+available);
		}
	}
	public static void main(String[] args) 
	{
		Reservation obj = new Reservation(1);

		Thread t1 = new Thread(obj,"Amar");
		Thread t2 = new Thread(obj,"Srinu");

		t1.start();
		t2.start();
	}
}