//Connecting to databse
import java.sql.*;
class DBMD
{
	public static void main(String[] args) 
	{
		try{
			Driver drv = new oracle.jdbc.driver.OracleDriver();
			DriverManager.registerDriver(drv);
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","surya","surya");
			System.out.println("Connected -----> "+con.getClass());
			Thread.sleep(500);
			
			DatabaseMetaData dbmd = con.getMetaData();
			System.out.println(dbmd.getDatabaseProductName());
			System.out.println(dbmd.getDatabaseProductVersion());
			System.out.println(dbmd.supportsStoredProcedures());
			System.out.println(dbmd.getMaxStatementLength());
			System.out.println(dbmd.getDriverName());
			System.out.println(dbmd.getDriverVersion());
			
			con.close();
			System.out.println("Disconnected ........");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}