import java.sql.*;
class Read1
{
	public static void main(String[] args) 
	{
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","surya","surya");
			Statement stmt = con.createStatement(
			ResultSet.TYPE_SCROLL_SENSITIVE,	
			ResultSet.CONCUR_READ_ONLY);

			String str = "select sname from student";

			ResultSet rs = stmt.executeQuery(str);

			rs.absolute(2);
			
			System.out.println("Current Row ---> "+rs.getRow());

			//System.out.println(rs.getString("sid"));
			System.out.println(rs.getString("sname"));
			//System.out.println(rs.getString("age"));
			//System.out.println(rs.getString("address"));
			
			System.in.read();
			System.in.read();

			rs.refreshRow();

			System.out.println(rs.getString("sname"));
		}
		catch(Exception e){
			System.out.println("Error");
			System.out.println(e);
		}
	}
}