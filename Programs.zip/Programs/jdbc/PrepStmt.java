//Demo on Stmt Obj
import java.sql.*;
class PrepStmt
{
	public static void main(String[] args) 
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:oci:@localhost","ipad","ipad");

			String str = "insert into tt values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(str);

			long t1,t2,diff;
			t1 = System.currentTimeMillis();

			for (int i=1;i<=100;i++)
			{
				ps.setInt(1,i);
				ps.setInt(2,i);
				ps.setInt(3,i);

				ps.executeUpdate();
			}

			t2 = System.currentTimeMillis();

			diff = t2-t1;

			System.out.println(diff);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
}