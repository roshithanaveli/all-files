//demo on jdbc type1 driver
import java.sql.*;
class DBApp1
{
	public static void main(String[] args) 
	{
		Connection con = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","surya","surya");
			Statement stmt = con.createStatement();
			String vsql = "insert into student values (1,'surya',17,'dsdfsdfsdf')";
			int i = stmt.executeUpdate(vsql);
			System.out.println("Executed --> "+vsql);
			System.out.println("Effected Rows --> "+i);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}