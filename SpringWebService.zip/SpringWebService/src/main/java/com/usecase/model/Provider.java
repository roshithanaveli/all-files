package com.usecase.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "Provider")
public class Provider {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
   private String name;
   private Date dob;
   private Integer contactNo;
   private String qualification;
   private String certificateId;
   private String Speciality;

   
	public Long getId() {
	return id;
}


public void setId(Long id) {
	this.id = id;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public Date getDob() {
	return dob;
}


public void setDob(Date dob) {
	this.dob = dob;
}


public Integer getContactNo() {
	return contactNo;
}


public void setContactNo(Integer contactNo) {
	this.contactNo = contactNo;
}


public String getQualification() {
	return qualification;
}


public void setQualification(String qualification) {
	this.qualification = qualification;
}


public String getCertificateId() {
	return certificateId;
}


public void setCertificateId(String certificateId) {
	this.certificateId = certificateId;
}


public String getSpeciality() {
	return Speciality;
}


public void setSpeciality(String speciality) {
	Speciality = speciality;
}


@Override
public String toString() {
	return "Provider [id=" + id + ", name=" + name + ", dob=" + dob
			+ ", contactNo=" + contactNo + ", qualification=" + qualification
			+ ", certificateId=" + certificateId + ", Speciality=" + Speciality
			+ "]";
}


	
   
   
}