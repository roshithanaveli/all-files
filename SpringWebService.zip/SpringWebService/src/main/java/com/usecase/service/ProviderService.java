package com.usecase.service;

import java.util.List;

import com.usecase.model.Provider;

public interface ProviderService {

	long save(Provider provider);

	Provider get(long id);
/*
	List<Provider> list();

	void update(long id, Provider provider);

	void delete(long id);*/
}
