package com.usecase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.usecase.dao.ProviderDao;
import com.usecase.model.Provider;


@Service
@Transactional(readOnly = true)
public class ProviderServiceImpl implements ProviderService {

   @Autowired
   private ProviderDao providerDao;

   
   @Override
   public Provider get(long id) {
      return providerDao.get(id);
   }
   
  @Transactional
  @Override
   public long save(Provider provider) {
	// TODO Auto-generated method stub
	return 0;
}

  /* @Override
   public List<Provider> list() {
      return providerDao.list();
   }

   @Transactional
   @Override
   public void update(long id, Provider provider) {
      providerDao.update(id, provider);
   }

   @Transactional
   @Override
   public void delete(long id) {
      providerDao.delete(id);
   }*/    
}