package com.usecase.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.usecase.model.Provider;
import com.usecase.service.ProviderService;


@CrossOrigin(origins = "*")
@RestController
public class ProviderController {

   @Autowired
   private ProviderService providerService;

   /*---Add new Provider---*/
   @PostMapping("/provider")
   public ResponseEntity<?> save(@RequestBody Provider provider) {
	  System.out.println("the json value of provider is :::::: "+provider);
      long id = providerService.save(provider);
      return ResponseEntity.ok().body("New Provider has been saved with ID:" + id);
   }
   
   /*---Get a Provider by id---*/
   @GetMapping("/provider/{id}")
   public ResponseEntity<Provider> get(@PathVariable("id") long id) {
      Provider provider = providerService.get(id);
      return ResponseEntity.ok().body(provider);
   }

   /*---get all Providers---*/
  /* @GetMapping("/provider")
   public ResponseEntity<List<Provider>> list() {
      List<Provider> providers = providerService.list();
      return ResponseEntity.ok().body(providers);
   }

   /*---Update a Provider by id---
   @PutMapping("/provider/{id}")
   public ResponseEntity<?> update(@PathVariable("id") long id, @RequestBody Provider provider) {
      providerService.update(id, provider);
      return ResponseEntity.ok().body("Provider has been updated successfully.");
   }

   /*---Delete a Provider by id---
   @DeleteMapping("/provider/{id}")
   public ResponseEntity<?> delete(@PathVariable("id") long id) {
      providerService.delete(id);
      return ResponseEntity.ok().body("Provider has been deleted successfully.");
   }*/
}