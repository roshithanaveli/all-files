package com.usecase.dao;

import java.util.List;

import com.usecase.model.Provider;


public interface ProviderDao {

   long save(Provider provider);

   Provider get(long id);

  /*List<Provider> list();

   void update(long id, Provider provider);

   void delete(long id);

Provider get(Long id);
*/

}

