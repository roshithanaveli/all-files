package com.usecase.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.usecase.model.Provider;


@Repository
public class ProviderDaoImpl implements ProviderDao {

	@Autowired
	   private SessionFactory sessionFactory;

	   @Override
	   public long save(Provider provider) {
	      sessionFactory.getCurrentSession().save(provider);
	      return provider.getId();
	   }

	   @Override
	   public Provider get(Long id) {
	      return sessionFactory.getCurrentSession().get(Provider.class, id);
	   }

	@Override
	public Provider get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Provider> list() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(long id, Provider provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(long id) {
		// TODO Auto-generated method stub
		
	}

	   /*@Override
	   public List<Provider> list() {
	      Session session = sessionFactory.getCurrentSession();
	      CriteriaBuilder cb = session.getCriteriaBuilder();
	      CriteriaQuery<Provider> cq = cb.createQuery(Provider.class);
	      Root<Provider> root = cq.from(Provider.class);
	      cq.select(root);
	      Query<Provider> query = session.createQuery(cq);
	      return query.getResultList();
	   }*/

	  /* @Override
	   public void update(long id, Provider provider) {
	      Session session = sessionFactory.getCurrentSession();
	      Provider provider2 = session.byId(Provider.class).load(id);
	      provider2.setTitle(provider.getTitle());
	      provider2.setAuthor(provider.getAuthor());
	      session.flush();
	   }

	   @Override
	   public void delete(long id) {
	      Session session = sessionFactory.getCurrentSession();
	      Provider provider = session.byId(Provider.class).load(id);
	      session.delete(provider);
	   }*/
}